# 📋 Changelog — Clínica Hope

Todas as mudanças notáveis do projeto serão documentadas aqui.

## [2.0.0] — 2026-02-25

### ✨ Adicionado
- Site público completo com 7 seções
- Seção Hero com card da fundadora Beatriz Santiago
- Módulo de Especialistas com 9 cards funcionais (foto, abordagem, turnos, CTA)
- Seção de Avaliações Google (5 estrelas) com carrossel automático
- Seção de Planos de Saúde com grade de convênios
- Seção de Sublocação de Salas estilo boutique com galeria e preços
- Modal de Agendamento em 3 etapas → WhatsApp
- Botão flutuante de WhatsApp
- Painel Admin com 14 módulos
- Dashboard com KPIs, alertas e visão geral
- Agenda Central com filtros por dia e psicóloga
- Módulo de Pacientes com busca e WhatsApp
- Módulo de Guias com controle semanal
- Mapa de Ocupação de Salas (5 salas × 10 horários)
- Validação Financeira (NF/RPA) por profissional
- Análise de Glosas TISS com upload de XML
- Formulário de Credenciamento em 4 etapas
- Gestão de Sublocação
- Painel Google Sheets (planilhas conectadas)
- Painel Google Drive (pastas e atividade)
- Editor de conteúdo do site (CMS básico)
- Tela de Configurações com integrações
- Tela de Login com design profissional
- Link "Acesso Restrito" no footer

### 🎨 Design
- Paleta: verde sálvia + azul suave + dourado + branco
- Tipografia: Cormorant Garamond (serifada) + Outfit (sans) + JetBrains Mono
- Responsivo preparado para mobile

## [1.0.0] — 2025-XX-XX

### Versão Original (Google Apps Script)
- Módulos individuais em Google Apps Script
- Formulários HTML separados
- Integração direta com Google Sheets
- Sem site público unificado
