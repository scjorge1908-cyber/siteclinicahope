# 🔗 Integração com Google — Clínica Hope

## Visão Geral

O sistema usa 3 serviços do Google como backend:

```
┌──────────────┐     ┌──────────────┐     ┌──────────────┐
│ Google Sheets│     │ Google Drive  │     │ Apps Script  │
│  (Dados)     │◄───►│  (Arquivos)  │◄───►│  (Backend)   │
└──────────────┘     └──────────────┘     └──────────────┘
```

---

## 📊 Google Sheets — Estrutura das Planilhas

### Planilha Mestre
**ID:** Configurar em `.env` → `VITE_MASTER_SHEET_ID`

| Aba | Colunas Principais | Usado por |
|-----|-------------------|-----------|
| `Pacientes` | Nome, CPF, Nascimento, Tel, Plano, Psicóloga | Pacientes, Agenda |
| `Profissionais` | Nome, CRP, Especialidade, Turnos, Status | Especialistas |
| `Agenda` | Data, Hora, Paciente, Psicóloga, Sala, Status | Agenda Central |
| `Salas` | Sala, Dia, Horário, Ocupante | Mapa de Salas |
| `Config` | Parâmetro, Valor | Configurações |

### Planilhas Individuais (1 por psicóloga)
Conectadas via `IMPORTRANGE` à planilha mestre.

| Aba | Conteúdo |
|-----|----------|
| `Agenda` | Horários da semana |
| `Pacientes` | Lista de pacientes ativos |
| `Guias` | Controle semanal de guias |
| `Financeiro` | Valores e faturamento |

### Planilha Financeira
| Aba | Conteúdo |
|-----|----------|
| `NF` | Notas fiscais por mês |
| `RPA` | RPAs por mês |
| `Validação` | Status NF + RPA por profissional |

### Fórmulas IMPORTRANGE

```
// Na planilha individual de cada psicóloga:
=IMPORTRANGE("ID_PLANILHA_MESTRE"; "Agenda!A:H")

// Filtrar só os dados dela:
=FILTER(IMPORTRANGE("ID_MESTRE"; "Agenda!A:H"); IMPORTRANGE("ID_MESTRE"; "Agenda!E:E") = "Dra. Michelle")
```

---

## ☁️ Google Drive — Estrutura de Pastas

```
📁 Clínica Hope (Raiz)
├── 📁 Credenciamento_Hope_Oficial/
│   ├── 📄 Credenciamento_Michelle_2025.pdf
│   ├── 📄 Credenciamento_Lana_2025.pdf
│   └── ...
│
├── 📁 documento Hope/
│   ├── 📄 Alvará_Funcionamento.pdf
│   ├── 📄 Licenca_Sanitaria.pdf
│   ├── 📄 Certificado_CNES.pdf
│   └── ...
│
├── 📁 Glosa Hope/
│   ├── 📁 2026/
│   │   ├── 📄 Janeiro/
│   │   │   ├── XML_Unimed_Jan2026.xml
│   │   │   └── Relatorio_Glosa_Jan2026.pdf
│   │   └── ...
│
├── 📁 Notas Fiscais 2026/
│   ├── 📄 NF_Michelle_Jan2026.pdf
│   ├── 📄 NF_Gabriella_Jan2026.pdf
│   └── ...
│
├── 📁 RPAs 2026/
│   ├── 📄 RPA_Michelle_Jan2026.pdf
│   └── ...
│
├── 📁 Relatórios Gerados/
│   ├── 📄 Relatorio_Salas_Fev2026.pdf
│   └── ...
│
└── 📁 Assinaturas Digitais/
    ├── 📄 Assinatura_Michelle.png
    └── ...
```

---

## ⚡ Google Apps Script — Funções Backend

### Arquivo: `Codigo.gs` (Principal)

```javascript
// Função principal — serve a interface web
function doGet(e) {
  var page = e.parameter.page || "painel";
  return HtmlService
    .createTemplateFromFile(page)
    .evaluate()
    .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
}

// Incluir arquivos HTML/CSS/JS
function include(filename) {
  return HtmlService.createHtmlOutputFromFile(filename).getContent();
}
```

### Triggers Automáticos

```javascript
// Configurar no Apps Script → Triggers:

// 1. Validação diária (20h)
function triggerValidacaoDiaria() {
  // Verifica NF/RPA pendentes
  // Envia alertas por email
}

// 2. Sincronização a cada 15 min
function triggerSyncAgendas() {
  // Atualiza IMPORTRANGE
  // Verifica conflitos de sala
}

// 3. Backup semanal (domingo 3h)
function triggerBackupSemanal() {
  // Copia planilha mestre para Drive
}
```

---

## 🔐 Permissões Necessárias

| Serviço | Escopo | Motivo |
|---------|--------|--------|
| Sheets | `spreadsheets` | Ler/escrever dados |
| Drive | `drive.file` | Upload/download de arquivos |
| Script | `script.webapp` | Servir interface web |
| Gmail | `gmail.send` | Alertas automáticos |

---

## ⚠️ Limites do Google

| Recurso | Limite |
|---------|--------|
| Sheets API | 300 requests/min |
| Drive storage | 15 GB (gratuito) |
| Apps Script | 6 min/execução |
| Triggers | 20 por projeto |
| IMPORTRANGE | 50 por planilha |
