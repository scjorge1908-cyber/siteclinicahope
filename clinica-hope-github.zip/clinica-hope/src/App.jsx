// ═══════════════════════════════════════════════════════════════
// App.jsx — Clínica Hope — Entry Point / Router
// ═══════════════════════════════════════════════════════════════
import { useState } from "react";
import { GOOGLE_FONTS_URL } from "./constants";

// Site Components
import Website from "./site/Website";

// Admin Components
import LoginScreen from "./admin/LoginScreen";
import AdminPanel from "./admin/AdminPanel";

export default function App() {
  const [view, setView] = useState("site"); // "site" | "login" | "admin"
  const [authenticated, setAuthenticated] = useState(false);

  const goToAdmin = () => setView("login");
  const goToSite = () => {
    setView("site");
    setAuthenticated(false);
  };
  const handleLogin = () => {
    setAuthenticated(true);
    setView("admin");
  };

  return (
    <>
      {/* Google Fonts — carregado uma vez */}
      <link href={GOOGLE_FONTS_URL} rel="stylesheet" />

      {/* Roteamento simples por estado */}
      {view === "site" && <Website onAdmin={goToAdmin} />}

      {view === "login" && !authenticated && (
        <LoginScreen onLogin={handleLogin} onBack={goToSite} />
      )}

      {view === "admin" && authenticated && (
        <AdminPanel onLogout={goToSite} />
      )}
    </>
  );
}
