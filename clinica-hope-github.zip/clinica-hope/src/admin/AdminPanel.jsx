// TODO: Implementar componente AdminPanel
// Ver clinica-hope-site.jsx para o código completo
export default function AdminPanel() {
  return <div>AdminPanel — Em desenvolvimento</div>;
}
