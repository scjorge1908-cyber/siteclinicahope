// TODO: Implementar componente LoginScreen
// Ver clinica-hope-site.jsx para o código completo
export default function LoginScreen() {
  return <div>LoginScreen — Em desenvolvimento</div>;
}
