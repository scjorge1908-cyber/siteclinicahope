// TODO: Implementar componente TopBar
// Ver clinica-hope-site.jsx para o código completo
export default function TopBar() {
  return <div>TopBar — Em desenvolvimento</div>;
}
