// TODO: Implementar Badge
export default function Badge({ children }) {
  return <div>{children}</div>;
}
