// TODO: Implementar Button
export default function Button({ children }) {
  return <div>{children}</div>;
}
