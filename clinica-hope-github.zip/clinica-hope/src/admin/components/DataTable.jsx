// TODO: Implementar DataTable
export default function DataTable({ children }) {
  return <div>{children}</div>;
}
