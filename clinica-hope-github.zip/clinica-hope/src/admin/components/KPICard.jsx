// TODO: Implementar KPICard
export default function KPICard({ children }) {
  return <div>{children}</div>;
}
