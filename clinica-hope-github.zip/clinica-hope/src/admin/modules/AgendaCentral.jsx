// TODO: Implementar AgendaCentral
export default function AgendaCentral() {
  return <div>AgendaCentral</div>;
}
