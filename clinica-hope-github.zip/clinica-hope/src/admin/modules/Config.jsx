// TODO: Implementar Config
export default function Config() {
  return <div>Config</div>;
}
