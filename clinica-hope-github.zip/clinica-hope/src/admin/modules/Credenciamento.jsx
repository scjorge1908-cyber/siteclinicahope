// TODO: Implementar Credenciamento
export default function Credenciamento() {
  return <div>Credenciamento</div>;
}
