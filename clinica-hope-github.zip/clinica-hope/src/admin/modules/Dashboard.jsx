// TODO: Implementar Dashboard
export default function Dashboard() {
  return <div>Dashboard</div>;
}
