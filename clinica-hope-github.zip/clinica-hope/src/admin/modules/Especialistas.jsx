// TODO: Implementar Especialistas
export default function Especialistas() {
  return <div>Especialistas</div>;
}
