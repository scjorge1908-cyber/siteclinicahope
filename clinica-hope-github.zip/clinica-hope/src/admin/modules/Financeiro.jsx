// TODO: Implementar Financeiro
export default function Financeiro() {
  return <div>Financeiro</div>;
}
