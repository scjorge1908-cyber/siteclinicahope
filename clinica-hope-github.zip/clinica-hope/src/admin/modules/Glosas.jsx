// TODO: Implementar Glosas
export default function Glosas() {
  return <div>Glosas</div>;
}
