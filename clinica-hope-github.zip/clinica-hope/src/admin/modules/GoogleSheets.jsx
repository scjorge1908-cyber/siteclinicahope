// TODO: Implementar GoogleSheets
export default function GoogleSheets() {
  return <div>GoogleSheets</div>;
}
