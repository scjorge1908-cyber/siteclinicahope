// TODO: Implementar Guias
export default function Guias() {
  return <div>Guias</div>;
}
