// TODO: Implementar Pacientes
export default function Pacientes() {
  return <div>Pacientes</div>;
}
