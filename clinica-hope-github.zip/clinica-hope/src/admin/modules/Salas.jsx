// TODO: Implementar Salas
export default function Salas() {
  return <div>Salas</div>;
}
