// ═══════════════════════════════════════════════════════════════
// CLÍNICA HOPE — Design Tokens & Constants
// ═══════════════════════════════════════════════════════════════

export const COLORS = {
  // Primárias
  sage: "#7c9a8b",
  sageLt: "#e8f0ec",
  sageDk: "#4a6b5c",

  // Secundárias
  blue: "#6b8fa3",
  blueLt: "#edf3f7",
  blueDk: "#3d6478",

  // Neutras
  cream: "#faf8f5",
  white: "#ffffff",
  warmWhite: "#f9f7f4",

  // Destaques
  gold: "#c4a35a",
  goldLt: "#f8f3e8",
  goldSoft: "#dcc88e",

  // Status
  red: "#c0392b",
  redLt: "#fdecea",
  ok: "#27ae60",
  okLt: "#eafaf1",
  warn: "#e67e22",
  warnLt: "#fef6ee",

  // Texto
  text: "#2d3436",
  textSoft: "#636e72",
  textMuted: "#95a5a6",

  // Bordas
  border: "#e8e4df",
  borderLt: "#f0ede8",

  // Admin
  deepGreen: "#1a3a2a",
  adminBg: "#f5f7f6",
};

export const FONTS = {
  serif: "'Cormorant Garamond', 'Playfair Display', Georgia, serif",
  sans: "'Outfit', 'DM Sans', 'Segoe UI', sans-serif",
  mono: "'JetBrains Mono', 'Fira Code', monospace",
};

export const GOOGLE_FONTS_URL =
  "https://fonts.googleapis.com/css2?family=Cormorant+Garamond:wght@300;400;500;600;700&family=Outfit:wght@300;400;500;600;700&family=JetBrains+Mono:wght@400;500&display=swap";

export const CLINIC_INFO = {
  name: "Clínica Hope",
  fullName: "Hope Clínica Multidisciplinar LTDA",
  cnpj: "47.283.631/0001-29",
  founder: "Beatriz Santiago",
  founderTitle: "CEO & Fundadora",
  founderCrp: "CRP 12/XXXXX",
  phone: "(48) 3333-4444",
  whatsapp: "(48) 99999-9999",
  whatsappLink: "5548999999999",
  email: "contato@clinicahopebrasil.com.br",
  address: "Palhoça, Santa Catarina — SC",
  hours: "Segunda a Sexta, 8h às 19h",
  domain: "clinicahopebrasil.com.br",
  slogan: "Onde o acolhimento encontra a ciência.",
  googleRating: "5.0",
};

export const NAV_LINKS = [
  { id: "home", label: "Home" },
  { id: "quem-somos", label: "Quem Somos" },
  { id: "especialistas", label: "Especialistas" },
  { id: "sublocacao", label: "Sublocação" },
  { id: "contato", label: "Contato" },
];

export const ADMIN_MODULES = [
  { id: "dash", label: "Dashboard", icon: "📊" },
  { id: "agenda", label: "Agenda Central", icon: "📅" },
  { id: "pacientes", label: "Pacientes", icon: "👥" },
  { id: "especialistas", label: "Especialistas", icon: "🩺" },
  { id: "guias", label: "Guias", icon: "📋" },
  { id: "salas", label: "Salas", icon: "🏥" },
  { id: "financeiro", label: "Financeiro", icon: "💰" },
  { id: "glosas", label: "Glosas TISS", icon: "⚠️" },
  { id: "sublocacao", label: "Sublocação", icon: "🔑" },
  { id: "credenciamento", label: "Credenciamento", icon: "📝" },
  { id: "sheets", label: "Google Sheets", icon: "📊" },
  { id: "drive", label: "Google Drive", icon: "☁️" },
  { id: "site", label: "Editar Site", icon: "🌐" },
  { id: "config", label: "Configurações", icon: "⚙️" },
];
