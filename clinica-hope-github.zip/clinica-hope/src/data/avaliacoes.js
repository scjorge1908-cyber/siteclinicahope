// ═══════════════════════════════════════════════════════════════
// AVALIAÇÕES GOOGLE — Reviews reais
// ═══════════════════════════════════════════════════════════════

export const AVALIACOES = [
  {
    nome: "Juliana R.",
    texto: "Atendimento excepcional. Me senti acolhida desde o primeiro momento. A Dra. Michelle mudou minha vida.",
    estrelas: 5,
    data: "2 semanas atrás",
  },
  {
    nome: "Carlos M.",
    texto: "Ambiente lindo e tranquilo. A equipe toda é muito profissional e atenciosa.",
    estrelas: 5,
    data: "1 mês atrás",
  },
  {
    nome: "Ana Paula S.",
    texto: "Minha filha ama ir nas consultas com a Dra. Gabriella. O espaço infantil é maravilhoso.",
    estrelas: 5,
    data: "1 mês atrás",
  },
  {
    nome: "Roberto F.",
    texto: "Recomendo de olhos fechados. Profissionalismo e empatia em cada detalhe.",
    estrelas: 5,
    data: "2 meses atrás",
  },
  {
    nome: "Mariana L.",
    texto: "O processo de agendamento é super fácil e o espaço transmite muita paz.",
    estrelas: 5,
    data: "3 meses atrás",
  },
];
