// ═══════════════════════════════════════════════════════════════
// PLANOS DE SAÚDE — Convênios aceitos
// ═══════════════════════════════════════════════════════════════

export const PLANOS = [
  { nome: "Unimed", categoria: "Nacional", logoFile: "unimed.svg" },
  { nome: "Bradesco Saúde", categoria: "Nacional", logoFile: "bradesco-saude.svg" },
  { nome: "SulAmérica", categoria: "Nacional", logoFile: "sulamerica.svg" },
  { nome: "Cassi", categoria: "Nacional", logoFile: "cassi.svg" },
  { nome: "Geap", categoria: "Servidor Público", logoFile: "geap.svg" },
  { nome: "PASA/VALE", categoria: "Corporativo", logoFile: "pasa.svg" },
  { nome: "Particular", categoria: "Particular", logoFile: null },
];
