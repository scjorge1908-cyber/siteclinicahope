// ═══════════════════════════════════════════════════════════════
// SALAS — Configuração e dados de sublocação
// ═══════════════════════════════════════════════════════════════

export const SALAS = [
  {
    id: "sala-1",
    titulo: "Sala de Atendimento 1",
    desc: "Decoração acolhedora com iluminação natural e poltronas confortáveis",
    foto: "sala-1.jpg",
    metragem: "12m²",
    equipamentos: ["Poltrona reclinável", "Mesa lateral", "Ar-condicionado", "Isolamento acústico"],
  },
  {
    id: "sala-2",
    titulo: "Sala de Atendimento 2",
    desc: "Ambiente silencioso com isolamento acústico premium",
    foto: "sala-2.jpg",
    metragem: "14m²",
    equipamentos: ["Sofá 3 lugares", "Poltrona", "Ar-condicionado", "Isolamento acústico"],
  },
  {
    id: "sala-infantil",
    titulo: "Sala Infantil",
    desc: "Espaço lúdico e colorido para atendimento de crianças",
    foto: "sala-infantil.jpg",
    metragem: "16m²",
    equipamentos: ["Brinquedos terapêuticos", "Tapete", "Mesa infantil", "Ar-condicionado"],
  },
  {
    id: "recepcao",
    titulo: "Recepção",
    desc: "Área de espera confortável com café cortesia e Wi-Fi",
    foto: "recepcao.jpg",
    metragem: "20m²",
    equipamentos: ["Sofás", "Café/água", "Wi-Fi", "TV"],
  },
  {
    id: "sala-4",
    titulo: "Sala de Atendimento 4",
    desc: "Design minimalista e relaxante com cores suaves",
    foto: "sala-4.jpg",
    metragem: "11m²",
    equipamentos: ["Poltrona", "Mesa lateral", "Ar-condicionado", "Isolamento acústico"],
  },
];

export const PRECOS_SUBLOCACAO = {
  avulso: {
    valor: 35,
    unidade: "hora",
    descricao: "Por hora de atendimento",
  },
  pacoteMensal: {
    valor: 800,
    unidade: "mês",
    descricao: "Turno fixo (manhã ou tarde) — segunda a sexta",
    destaque: true,
    label: "MELHOR CUSTO",
  },
  pacoteSemanal: {
    valor: 250,
    unidade: "semana",
    descricao: "Um turno por semana",
  },
};

export const DIFERENCIAIS = [
  "📶 Wi-Fi de alta velocidade",
  "☕ Recepção com café cortesia",
  "❄️ Ar-condicionado individual",
  "🔇 Isolamento acústico profissional",
  "📍 Localização central — Palhoça/SC",
  "🚗 Estacionamento gratuito",
  "🧹 Limpeza e higienização diária",
  "🔐 Acesso por código individual",
];
