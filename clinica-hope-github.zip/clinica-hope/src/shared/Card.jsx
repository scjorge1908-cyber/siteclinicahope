// TODO: Implementar Card
export default function Card({ children }) {
  return <div>{children}</div>;
}
