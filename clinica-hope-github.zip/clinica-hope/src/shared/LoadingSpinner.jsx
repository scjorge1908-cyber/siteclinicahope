// TODO: Implementar LoadingSpinner
export default function LoadingSpinner({ children }) {
  return <div>{children}</div>;
}
