// TODO: Implementar Modal
export default function Modal({ children }) {
  return <div>{children}</div>;
}
