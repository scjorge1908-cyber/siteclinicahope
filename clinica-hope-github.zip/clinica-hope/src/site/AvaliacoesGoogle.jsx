// TODO: Implementar AvaliacoesGoogle
export default function AvaliacoesGoogle() {
  return <div>AvaliacoesGoogle</div>;
}
