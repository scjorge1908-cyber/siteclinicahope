// TODO: Implementar Contato
export default function Contato() {
  return <div>Contato</div>;
}
