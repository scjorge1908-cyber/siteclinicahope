// TODO: Implementar Footer
export default function Footer() {
  return <div>Footer</div>;
}
