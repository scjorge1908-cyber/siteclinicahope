// ═══════════════════════════════════════════════════════════════
// HeroSection.jsx — Home / Hero da Clínica Hope
// Seção principal com: Slogan + Beatriz Santiago + Selo Google
// ═══════════════════════════════════════════════════════════════
import { useState, useEffect } from "react";
import { COLORS as C, FONTS, CLINIC_INFO } from "../constants";

export default function HeroSection({ onAgendar }) {
  const [loaded, setLoaded] = useState(false);

  useEffect(() => {
    const t = setTimeout(() => setLoaded(true), 100);
    return () => clearTimeout(t);
  }, []);

  const fadeIn = (delay = 0) => ({
    opacity: loaded ? 1 : 0,
    transform: loaded ? "translateY(0)" : "translateY(24px)",
    transition: `all 0.8s cubic-bezier(0.16, 1, 0.3, 1) ${delay}ms`,
  });

  return (
    <section
      id="home"
      style={{
        padding: "100px 32px 80px",
        position: "relative",
        overflow: "hidden",
        background: `linear-gradient(160deg, ${C.warmWhite} 0%, ${C.sageLt} 50%, ${C.blueLt} 100%)`,
      }}
    >
      {/* ── Decorative Elements ── */}
      <div style={{ position: "absolute", top: 40, right: "10%", width: 300, height: 300, borderRadius: "50%", border: `1px solid ${C.sage}20`, opacity: 0.4 }} />
      <div style={{ position: "absolute", bottom: -40, left: "5%", width: 200, height: 200, borderRadius: "50%", background: `${C.blue}08` }} />
      <div style={{ position: "absolute", top: 80, left: "12%", width: 120, height: 120, borderRadius: "50%", border: `1px dashed ${C.gold}20` }} />
      {/* Floating dots */}
      {[
        { top: 120, right: "5%", s: 6, c: C.gold },
        { top: 200, right: "15%", s: 4, c: C.sage },
        { bottom: 80, left: "20%", s: 5, c: C.gold },
        { top: 300, left: "8%", s: 3, c: C.blue },
        { bottom: 120, right: "25%", s: 4, c: C.sage },
      ].map((dot, i) => (
        <div
          key={i}
          style={{
            position: "absolute",
            ...dot,
            width: dot.s,
            height: dot.s,
            borderRadius: "50%",
            background: dot.c,
            opacity: 0.5,
          }}
        />
      ))}

      {/* ── Main Content Grid ── */}
      <div
        style={{
          maxWidth: 1200,
          margin: "0 auto",
          display: "grid",
          gridTemplateColumns: "1fr 1fr",
          gap: 60,
          alignItems: "center",
          position: "relative",
          zIndex: 1,
        }}
      >
        {/* ─── LEFT: Text Content ─── */}
        <div>
          {/* Google Badge */}
          <div style={{ ...fadeIn(0), display: "inline-flex", alignItems: "center", gap: 8, padding: "6px 16px", borderRadius: 50, background: `${C.gold}18`, marginBottom: 28 }}>
            <span style={{ color: C.gold, fontSize: 14 }}>★★★★★</span>
            <span style={{ fontSize: 11, fontWeight: 600, color: C.gold, letterSpacing: "0.08em" }}>
              {CLINIC_INFO.googleRating} NO GOOGLE
            </span>
          </div>

          {/* Headline */}
          <h1
            style={{
              ...fadeIn(150),
              fontFamily: FONTS.serif,
              fontSize: 54,
              fontWeight: 400,
              lineHeight: 1.12,
              color: C.text,
              marginBottom: 24,
              letterSpacing: "-0.015em",
            }}
          >
            Onde o{" "}
            <em style={{ fontStyle: "italic", color: C.sageDk }}>acolhimento</em>
            <br />
            encontra a{" "}
            <em style={{ fontStyle: "italic", color: C.blueDk }}>ciência</em>.
          </h1>

          {/* Subtext */}
          <p
            style={{
              ...fadeIn(300),
              fontSize: 17,
              color: C.textSoft,
              lineHeight: 1.8,
              marginBottom: 36,
              maxWidth: 480,
            }}
          >
            Cuidado psicológico humanizado com equipe especializada em diversas
            abordagens. Aceitamos os principais convênios e oferecemos um
            ambiente projetado para o seu bem-estar mental.
          </p>

          {/* CTAs */}
          <div style={{ ...fadeIn(450), display: "flex", gap: 14, marginBottom: 48 }}>
            <button
              onClick={() => onAgendar?.()}
              style={{
                padding: "16px 36px",
                borderRadius: 50,
                border: "none",
                cursor: "pointer",
                background: `linear-gradient(135deg, ${C.sageDk}, ${C.sage})`,
                color: "#fff",
                fontWeight: 600,
                fontSize: 15,
                fontFamily: FONTS.sans,
                boxShadow: `0 8px 28px ${C.sage}35`,
                transition: "transform 0.2s, box-shadow 0.2s",
              }}
              onMouseEnter={(e) => {
                e.target.style.transform = "translateY(-2px)";
                e.target.style.boxShadow = `0 12px 32px ${C.sage}45`;
              }}
              onMouseLeave={(e) => {
                e.target.style.transform = "translateY(0)";
                e.target.style.boxShadow = `0 8px 28px ${C.sage}35`;
              }}
            >
              Agendar Consulta
            </button>

            <a
              href={`https://wa.me/${CLINIC_INFO.whatsappLink}`}
              target="_blank"
              rel="noopener noreferrer"
              style={{
                padding: "16px 36px",
                borderRadius: 50,
                textDecoration: "none",
                border: `2px solid ${C.sage}40`,
                color: C.sageDk,
                fontWeight: 600,
                fontSize: 15,
                fontFamily: FONTS.sans,
                display: "flex",
                alignItems: "center",
                gap: 8,
                transition: "all 0.2s",
              }}
            >
              📱 WhatsApp
            </a>
          </div>

          {/* Quick info */}
          <div style={{ ...fadeIn(600), display: "flex", gap: 24, alignItems: "center" }}>
            {[
              { icon: "🕐", text: CLINIC_INFO.hours },
              { icon: "📍", text: "Palhoça/SC" },
            ].map((item, i) => (
              <div key={i} style={{ display: "flex", alignItems: "center", gap: 6 }}>
                <span style={{ fontSize: 14 }}>{item.icon}</span>
                <span style={{ fontSize: 12, color: C.textMuted, fontWeight: 500 }}>{item.text}</span>
              </div>
            ))}
          </div>
        </div>

        {/* ─── RIGHT: Founder Card ─── */}
        <div style={{ ...fadeIn(400), display: "flex", justifyContent: "center" }}>
          <div
            style={{
              background: C.white,
              borderRadius: 28,
              padding: "44px 40px",
              boxShadow: "0 24px 64px rgba(0,0,0,0.06)",
              maxWidth: 380,
              width: "100%",
              border: `1px solid ${C.border}`,
              position: "relative",
            }}
          >
            {/* Top gradient line */}
            <div
              style={{
                position: "absolute",
                top: -1,
                left: 40,
                right: 40,
                height: 3,
                background: `linear-gradient(90deg, ${C.sage}, ${C.gold}, ${C.blue})`,
                borderRadius: "0 0 4px 4px",
              }}
            />

            {/* Founder photo placeholder */}
            <div
              style={{
                width: 110,
                height: 110,
                borderRadius: "50%",
                margin: "0 auto 24px",
                background: `linear-gradient(135deg, ${C.sage}, ${C.blue})`,
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                color: "#fff",
                fontFamily: FONTS.serif,
                fontSize: 46,
                fontWeight: 300,
                boxShadow: `0 8px 28px ${C.sage}30`,
                position: "relative",
              }}
            >
              B
              {/* Status dot */}
              <div
                style={{
                  position: "absolute",
                  bottom: 4,
                  right: 4,
                  width: 20,
                  height: 20,
                  borderRadius: "50%",
                  background: C.gold,
                  border: "3px solid #fff",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  fontSize: 10,
                }}
              >
                ★
              </div>
            </div>

            <div style={{ textAlign: "center" }}>
              {/* Title */}
              <div
                style={{
                  fontSize: 10,
                  fontWeight: 600,
                  color: C.gold,
                  letterSpacing: "0.18em",
                  textTransform: "uppercase",
                  marginBottom: 8,
                }}
              >
                {CLINIC_INFO.founderTitle}
              </div>

              {/* Name */}
              <h3
                style={{
                  fontFamily: FONTS.serif,
                  fontSize: 28,
                  fontWeight: 600,
                  color: C.text,
                  marginBottom: 6,
                  letterSpacing: "-0.01em",
                }}
              >
                {CLINIC_INFO.founder}
              </h3>

              {/* CRP */}
              <div
                style={{
                  fontSize: 12,
                  color: C.sage,
                  fontWeight: 600,
                  marginBottom: 20,
                }}
              >
                Psicóloga Clínica — {CLINIC_INFO.founderCrp}
              </div>

              {/* Divider */}
              <div
                style={{
                  width: 40,
                  height: 1,
                  background: C.border,
                  margin: "0 auto 20px",
                }}
              />

              {/* Bio */}
              <p
                style={{
                  fontSize: 14,
                  color: C.textSoft,
                  lineHeight: 1.75,
                }}
              >
                Idealizadora da Clínica Hope, Beatriz é especialista em Terapia
                Cognitivo-Comportamental com mais de 10 anos de atuação clínica.
                Sua visão: criar um espaço onde ciência e empatia caminham juntas
                pelo bem-estar de cada paciente.
              </p>

              {/* Badges */}
              <div
                style={{
                  display: "flex",
                  justifyContent: "center",
                  gap: 8,
                  marginTop: 20,
                  flexWrap: "wrap",
                }}
              >
                {["TCC", "Ansiedade", "Depressão"].map((tag) => (
                  <span
                    key={tag}
                    style={{
                      padding: "4px 12px",
                      borderRadius: 50,
                      fontSize: 11,
                      fontWeight: 600,
                      background: `${C.sage}12`,
                      color: C.sageDk,
                    }}
                  >
                    {tag}
                  </span>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* ── Stats Bar ── */}
      <div
        style={{
          ...fadeIn(700),
          maxWidth: 1200,
          margin: "72px auto 0",
          display: "grid",
          gridTemplateColumns: "repeat(4, 1fr)",
          background: C.white,
          borderRadius: 20,
          padding: "32px 0",
          boxShadow: "0 4px 24px rgba(0,0,0,0.04)",
          border: `1px solid ${C.border}`,
          position: "relative",
          zIndex: 1,
        }}
      >
        {[
          { num: "9+", label: "Profissionais especializadas", icon: "🩺" },
          { num: "1.000+", label: "Vidas transformadas", icon: "💚" },
          { num: "5", label: "Salas equipadas", icon: "🏥" },
          { num: "5.0", label: "Avaliação Google", icon: "⭐" },
        ].map((stat, i) => (
          <div
            key={i}
            style={{
              textAlign: "center",
              borderRight: i < 3 ? `1px solid ${C.borderLt}` : "none",
              padding: "0 20px",
            }}
          >
            <div
              style={{
                fontSize: 36,
                fontFamily: FONTS.serif,
                fontWeight: 600,
                color: C.sageDk,
                lineHeight: 1,
                marginBottom: 6,
              }}
            >
              {stat.num}
            </div>
            <div
              style={{
                fontSize: 12,
                color: C.textMuted,
                fontWeight: 500,
              }}
            >
              {stat.icon} {stat.label}
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}
