// TODO: Implementar ModalAgendar
export default function ModalAgendar() {
  return <div>ModalAgendar</div>;
}
