// TODO: Implementar PlanosSaude
export default function PlanosSaude() {
  return <div>PlanosSaude</div>;
}
