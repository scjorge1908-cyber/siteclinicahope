// TODO: Implementar QuemSomos
export default function QuemSomos() {
  return <div>QuemSomos</div>;
}
