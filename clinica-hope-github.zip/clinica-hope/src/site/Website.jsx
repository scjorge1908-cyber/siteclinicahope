// ═══════════════════════════════════════════════════════════════
// Website.jsx — Layout principal do site público
// Importa e organiza todas as seções
// ═══════════════════════════════════════════════════════════════
import { useState, useEffect } from "react";
import { FONTS, COLORS as C, CLINIC_INFO, NAV_LINKS } from "../constants";

// Seções
import HeroSection from "./HeroSection";
// import QuemSomos from "./QuemSomos";
// import Especialistas from "./Especialistas";
// import AvaliacoesGoogle from "./AvaliacoesGoogle";
// import PlanosSaude from "./PlanosSaude";
// import Sublocacao from "./Sublocacao";
// import Contato from "./Contato";
// import Footer from "./Footer";
// import ModalAgendar from "./ModalAgendar";
// import WhatsAppFloat from "./WhatsAppFloat";

export default function Website({ onAdmin }) {
  const [activeSection, setActiveSection] = useState("home");
  const [agendarOpen, setAgendarOpen] = useState(false);
  const [agendarPsi, setAgendarPsi] = useState("");

  const openAgendar = (psiNome = "") => {
    setAgendarPsi(psiNome);
    setAgendarOpen(true);
  };

  return (
    <div style={{ fontFamily: FONTS.sans, color: C.text, background: C.white }}>
      {/* ── Navbar ── */}
      <Navbar
        active={activeSection}
        onNavigate={setActiveSection}
        onAgendar={() => openAgendar()}
        onAdmin={onAdmin}
      />

      {/* ── Seções ── */}
      <HeroSection onAgendar={() => openAgendar()} />
      {/* <QuemSomos /> */}
      {/* <Especialistas onAgendar={openAgendar} /> */}
      {/* <AvaliacoesGoogle /> */}
      {/* <PlanosSaude /> */}
      {/* <Sublocacao /> */}
      {/* <Contato /> */}
      {/* <Footer onAdmin={onAdmin} /> */}

      {/* ── Modals & Floats ── */}
      {/* {agendarOpen && <ModalAgendar onClose={() => setAgendarOpen(false)} psiInicial={agendarPsi} />} */}
      {/* <WhatsAppFloat /> */}
    </div>
  );
}

// ── Navbar Component (inline por ora) ──
function Navbar({ active, onNavigate, onAgendar, onAdmin }) {
  return (
    <nav
      style={{
        position: "sticky",
        top: 0,
        zIndex: 100,
        background: "rgba(255,255,255,0.96)",
        backdropFilter: "blur(16px)",
        borderBottom: `1px solid ${C.borderLt}`,
        padding: "0 32px",
      }}
    >
      <div
        style={{
          maxWidth: 1200,
          margin: "0 auto",
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
          height: 72,
        }}
      >
        {/* Logo */}
        <div style={{ display: "flex", alignItems: "center", gap: 14 }}>
          <div
            style={{
              width: 42,
              height: 42,
              borderRadius: 12,
              background: `linear-gradient(135deg, ${C.sage}, ${C.blue})`,
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              color: "#fff",
              fontFamily: FONTS.serif,
              fontWeight: 700,
              fontSize: 22,
            }}
          >
            H
          </div>
          <div>
            <div style={{ fontFamily: FONTS.serif, fontWeight: 700, fontSize: 20, color: C.sageDk }}>
              {CLINIC_INFO.name}
            </div>
            <div style={{ fontSize: 9, color: C.textMuted, letterSpacing: "0.18em", fontWeight: 600, textTransform: "uppercase" }}>
              Saúde Mental & Bem-Estar
            </div>
          </div>
        </div>

        {/* Nav Links */}
        <div style={{ display: "flex", alignItems: "center", gap: 32 }}>
          {NAV_LINKS.map(({ id, label }) => (
            <a
              key={id}
              href={`#${id}`}
              onClick={(e) => {
                e.preventDefault();
                onNavigate(id);
                document.getElementById(id)?.scrollIntoView({ behavior: "smooth" });
              }}
              style={{
                fontSize: 13,
                fontWeight: 500,
                color: active === id ? C.sageDk : C.textSoft,
                textDecoration: "none",
                paddingBottom: 4,
                borderBottom: active === id ? `2px solid ${C.sage}` : "2px solid transparent",
                transition: "all 0.3s",
              }}
            >
              {label}
            </a>
          ))}
          <button
            onClick={onAgendar}
            style={{
              padding: "10px 24px",
              borderRadius: 50,
              border: "none",
              cursor: "pointer",
              background: C.sageDk,
              color: "#fff",
              fontWeight: 600,
              fontSize: 13,
              fontFamily: FONTS.sans,
            }}
          >
            Agendar Consulta
          </button>
        </div>
      </div>
    </nav>
  );
}
