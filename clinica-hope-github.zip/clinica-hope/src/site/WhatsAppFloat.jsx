// TODO: Implementar WhatsAppFloat
export default function WhatsAppFloat() {
  return <div>WhatsAppFloat</div>;
}
